package co.edu.uniquindio.poo.proyectofinal_billeteravirtual.Model;

import java.io.Serializable;

public interface ICuenta extends Serializable {

    public void CrearCuenta();
    public void ModificarCuenta();
    public void EliminarCuenta();
}
