package co.edu.uniquindio.poo.proyectofinal_billeteravirtual.Model;

public class TransaccionRetiro implements Transaccion {

    @Override
    public void llenarDatos() {

    }
}
