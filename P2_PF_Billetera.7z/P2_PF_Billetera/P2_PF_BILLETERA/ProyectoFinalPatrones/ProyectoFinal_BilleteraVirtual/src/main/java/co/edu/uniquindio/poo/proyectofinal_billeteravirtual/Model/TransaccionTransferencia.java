package co.edu.uniquindio.poo.proyectofinal_billeteravirtual.Model;

public class TransaccionTransferencia implements Transaccion {


    @Override
    public void llenarDatos() {

    }
}
