package co.edu.uniquindio.poo.proyectofinal_billeteravirtual.Model;

public class TransaccionDeposito implements Transaccion {

    @Override
    public void llenarDatos() {

    }
}
