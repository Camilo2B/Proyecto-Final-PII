/*
package co.edu.uniquindio.poo.proyectofinal_billeteravirtual.ViewController;

import co.edu.uniquindio.poo.proyectofinal_billeteravirtual.Model.Usuario;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.io.IOException;

public class AdminController {

    @FXML
    private Label lblAdmin;

    @FXML
    private TableView<Usuario> tblUsuarios;

    @FXML
    private TableColumn<Usuario, String> colId;

    @FXML
    private TableColumn<Usuario, String> colNombre;

    @FXML
    private TableColumn<Usuario, String> colEmail;

    @FXML
    private TableColumn<Usuario, String> colTelefono;

    @FXML
    private TableColumn<Usuario, String> colDireccion;

    @FXML
    private TableColumn<Usuario, Double> colSaldo;

    @FXML
    private TableColumn<Usuario, Integer> colCuentas;

    @FXML
    private TableColumn<Usuario, Integer> colTransacciones;

    @FXML
    private Label lblTotalUsuarios;

    @FXML
    private Label lblTotalTransacciones;

    @FXML
    private Label lblVolumenTotal;

    private ObservableList<Usuario> usuariosList;

    // Método inicializador que se ejecuta cuando se carga el FXML
    @FXML
    public void initialize() {
        // Configurar las columnas de la tabla
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colTelefono.setCellValueFactory(new PropertyValueFactory<>("telefono"));
        colDireccion.setCellValueFactory(new PropertyValueFactory<>("direccion"));
        colSaldo.setCellValueFactory(new PropertyValueFactory<>("saldo"));
        colCuentas.setCellValueFactory(new PropertyValueFactory<>("numCuentas"));
        colTransacciones.setCellValueFactory(new PropertyValueFactory<>("numTransacciones"));

        // Inicializar la lista de usuarios
        usuariosList = FXCollections.observableArrayList();
        tblUsuarios.setItems(usuariosList);

        // Cargar datos iniciales (simulados o desde un servicio)
        cargarDatos();
        actualizarEstadisticas();

        // Establecer el nombre del administrador (simulado)
        lblAdmin.setText("Administrador: Admin1");
    }

    // Método para cerrar sesión y regresar a la pantalla de inicio de sesión
    @FXML
    private void cerrarSesion() {
        try {
            // Cargar la pantalla de inicio de sesión (suponiendo que tienes un login.fxml)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/poo/proyectofinal_billeteravirtual/View/login.fxml"));
            Parent root = loader.load();

            // Obtener el escenario actual y cambiar la escena
            Stage stage = (Stage) lblAdmin.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            mostrarAlerta("Error", "No se pudo cerrar sesión: " + e.getMessage());
        }
    }

    // Método para ver detalles del usuario seleccionado
    @FXML
    private void verDetallesUsuario() {
        Usuario usuarioSeleccionado = tblUsuarios.getSelectionModel().getSelectedItem();
        if (usuarioSeleccionado != null) {
            mostrarAlerta("Detalles del Usuario", "ID: " + usuarioSeleccionado.getIdGeneral() + "\nNombre: " + usuarioSeleccionado.getNombre() +
                    "\nEmail: " + usuarioSeleccionado.getEmail() + "\nTeléfono: " + usuarioSeleccionado.getTelefono() +
                    "\nSaldo: " + usuarioSeleccionado.getDireccion());
        } else {
            mostrarAlerta("Error", "Por favor, selecciona un usuario.");
        }
    }

    // Método para bloquear un usuario
    @FXML
    private void bloquearUsuario() {
        Usuario usuarioSeleccionado = tblUsuarios.getSelectionModel().getSelectedItem();
        if (usuarioSeleccionado != null) {
            usuarioSeleccionado.setBloqueado(true); // Suponiendo que tienes un atributo 'bloqueado' en Usuario
            mostrarAlerta("Éxito", "Usuario " + usuarioSeleccionado.getNombre() + " ha sido bloqueado.");
            tblUsuarios.refresh();
        } else {
            mostrarAlerta("Error", "Por favor, selecciona un usuario.");
        }
    }

    // Método para eliminar un usuario
    @FXML
    private void eliminarUsuario() {
        Usuario usuarioSeleccionado = tblUsuarios.getSelectionModel().getSelectedItem();
        if (usuarioSeleccionado != null) {
            usuariosList.remove(usuarioSeleccionado);
            actualizarEstadisticas();
            mostrarAlerta("Éxito", "Usuario " + usuarioSeleccionado.getNombre() + " ha sido eliminado.");
        } else {
            mostrarAlerta("Error", "Por favor, selecciona un usuario.");
        }
    }

    // Método para cargar datos iniciales (simulado)
    private void cargarDatos() {
        // Aquí deberías obtener los datos reales desde tu sistema (por ejemplo, BilleteraService)
        usuariosList.add(new Usuario("1", "Juan Pérez", "juan@example.com", "123456789", 1500.0));
        usuariosList.add(new Usuario("2", "María López", "maria@example.com", "987654321", 2300.0));
    }

    // Método para actualizar las estadísticas del sistema
    private void actualizarEstadisticas() {
        lblTotalUsuarios.setText(String.valueOf(usuariosList.size()));

        int totalTransacciones = usuariosList.stream()
                .mapToInt(Usuario::getNumTransacciones)
                .sum();
        lblTotalTransacciones.setText(String.valueOf(totalTransacciones));

        double volumenTotal = usuariosList.stream()
                .mapToDouble(Usuario::getSaldoTotal)
                .sum();
        lblVolumenTotal.setText(String.format("$%.2f", volumenTotal));
    }

    // Método auxiliar para mostrar alertas
    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}
*/
