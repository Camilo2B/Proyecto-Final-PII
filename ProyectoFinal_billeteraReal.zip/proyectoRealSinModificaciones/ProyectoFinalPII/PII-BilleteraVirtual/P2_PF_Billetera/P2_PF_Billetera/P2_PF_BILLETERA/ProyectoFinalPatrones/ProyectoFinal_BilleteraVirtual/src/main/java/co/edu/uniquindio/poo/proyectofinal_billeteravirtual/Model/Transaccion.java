package co.edu.uniquindio.poo.proyectofinal_billeteravirtual.Model;

import java.io.Serializable;

public interface Transaccion extends Serializable {
    public void llenarDatos();
}
