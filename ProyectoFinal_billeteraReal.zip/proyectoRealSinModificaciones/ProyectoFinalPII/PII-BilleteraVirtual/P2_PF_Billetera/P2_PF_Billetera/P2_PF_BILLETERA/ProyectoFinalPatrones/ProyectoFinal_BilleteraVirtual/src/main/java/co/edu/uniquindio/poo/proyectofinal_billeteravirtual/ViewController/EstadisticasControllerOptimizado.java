package co.edu.uniquindio.poo.proyectofinal_billeteravirtual.ViewController;

import co.edu.uniquindio.poo.proyectofinal_billeteravirtual.Model.*;
import co.edu.uniquindio.poo.proyectofinal_billeteravirtual.util.PerformanceOptimizer;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.util.StringConverter;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.ArrayList;

/**
 * Controlador optimizado para la vista de estadísticas
 * Implementa técnicas de optimización de rendimiento para mejorar la experiencia del usuario
 */
public class EstadisticasControllerOptimizado {

    @FXML
    private Label lblNombreUsuario;

    @FXML
    private Label lblSaldo;

    @FXML
    private ComboBox<String> cmbPeriodo;

    @FXML
    private DatePicker dpFechaInicio;

    @FXML
    private DatePicker dpFechaFin;

    @FXML
    private Button btnActualizar;

    @FXML
    private ProgressIndicator progressIndicator;

    @FXML
    private BarChart<String, Number> barChartCategorias;

    @FXML
    private CategoryAxis xAxisCategorias;

    @FXML
    private NumberAxis yAxisCategorias;

    @FXML
    private PieChart pieChartGastos;

    @FXML
    private LineChart<String, Number> lineChartTendencia;

    @FXML
    private CategoryAxis xAxisTendencia;

    @FXML
    private NumberAxis yAxisTendencia;

    private SceneController sceneController;
    private BilleteraService billeteraService;
    private DataManager dataManager;
    private Usuario usuarioActual;

    // Caché para evitar recálculos innecesarios
    private Map<String, Object> cacheResultados = new HashMap<>();

    /**
     * Inicializa el controlador
     */
    @FXML
    public void initialize() {
        sceneController = SceneController.getInstance();
        billeteraService = new BilleteraService();
        dataManager = DataManager.getInstance();

        // Verificar si hay un usuario logueado
        if (!billeteraService.hayUsuarioLogueado()) {
            // Si no hay usuario autenticado, redirigir a la vista de inicio de sesión
            try {
                sceneController.cambiarEscena(SceneController.VISTA_SESION);
                return;
            } catch (IOException e) {
                mostrarError("Error", "No se pudo cargar la vista de inicio de sesión: " + e.getMessage());
                e.printStackTrace();
            }
        }

        // Configurar la información del usuario
        usuarioActual = billeteraService.getUsuarioActual();
        if (usuarioActual != null) {
            lblNombreUsuario.setText(usuarioActual.getNombre());
            lblSaldo.setText("Saldo: $" + String.format("%.2f", usuarioActual.getSaldoTotal()));
        }

        // Configurar el combo box de períodos
        cmbPeriodo.setItems(FXCollections.observableArrayList(
            "Última semana", "Último mes", "Últimos 3 meses", "Último año", "Personalizado"
        ));

        cmbPeriodo.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                configurarFechasPorPeriodo(newVal);
            }
        });

        // Configurar los date pickers
        dpFechaInicio.setValue(LocalDate.now().minusMonths(1));
        dpFechaFin.setValue(LocalDate.now());

        // Seleccionar "Último mes" por defecto
        cmbPeriodo.getSelectionModel().select("Último mes");

        // Ocultar el indicador de progreso inicialmente
        progressIndicator.setVisible(false);

        // Inicializar los gráficos
        inicializarGraficos();
    }

    /**
     * Configura las fechas según el período seleccionado
     * @param periodo Período seleccionado
     */
    private void configurarFechasPorPeriodo(String periodo) {
        LocalDate hoy = LocalDate.now();

        switch (periodo) {
            case "Última semana":
                dpFechaInicio.setValue(hoy.minusWeeks(1));
                dpFechaFin.setValue(hoy);
                break;
            case "Último mes":
                dpFechaInicio.setValue(hoy.minusMonths(1));
                dpFechaFin.setValue(hoy);
                break;
            case "Últimos 3 meses":
                dpFechaInicio.setValue(hoy.minusMonths(3));
                dpFechaFin.setValue(hoy);
                break;
            case "Último año":
                dpFechaInicio.setValue(hoy.minusYears(1));
                dpFechaFin.setValue(hoy);
                break;
            case "Personalizado":
                // No hacer nada, dejar que el usuario seleccione las fechas
                break;
        }

        // Si no es personalizado, deshabilitar los date pickers
        boolean esPersonalizado = "Personalizado".equals(periodo);
        dpFechaInicio.setDisable(!esPersonalizado);
        dpFechaFin.setDisable(!esPersonalizado);

        // Actualizar los gráficos
        actualizarGraficos();
    }

    /**
     * Inicializa los gráficos
     */
    private void inicializarGraficos() {
        // Configurar ejes
        xAxisCategorias.setLabel("Categoría");
        yAxisCategorias.setLabel("Monto ($)");

        xAxisTendencia.setLabel("Fecha");
        yAxisTendencia.setLabel("Monto ($)");

        // Actualizar los gráficos
        actualizarGraficos();
    }

    /**
     * Actualiza los gráficos con los datos actuales de manera asíncrona
     */
    @FXML
    public void actualizarGraficos() {
        // Mostrar indicador de progreso
        progressIndicator.setVisible(true);

        // Crear una tarea en segundo plano para no bloquear la interfaz de usuario
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                // Obtener transacciones filtradas
                List<TransaccionFactory> transacciones = obtenerTransaccionesFiltradas();

                // Procesar datos para gráficos de manera asíncrona
                CompletableFuture<Map<String, Object>> futuroBarras =
                        PerformanceOptimizer.procesarDatosGraficoAsync(transacciones, "barras");

                CompletableFuture<Map<String, Object>> futuroPie =
                        PerformanceOptimizer.procesarDatosGraficoAsync(transacciones, "circular");

                CompletableFuture<Map<String, Object>> futuroLinea =
                        PerformanceOptimizer.procesarDatosGraficoAsync(transacciones, "linea");

                // Esperar a que todos los futuros se completen
                CompletableFuture.allOf(futuroBarras, futuroPie, futuroLinea).join();

                // Obtener resultados
                final Map<String, Object> datosBarras = futuroBarras.get();
                final Map<String, Object> datosPie = futuroPie.get();
                final Map<String, Object> datosLinea = futuroLinea.get();

                // Actualizar la interfaz de usuario en el hilo de JavaFX
                Platform.runLater(() -> {
                    try {
                        // Verificar y actualizar el gráfico de barras
                        Object datosBarrasObj = datosBarras.get("datos");
                        if (datosBarrasObj instanceof Map) {
                            @SuppressWarnings("unchecked")
                            Map<String, Double> gastosPorCategoria = (Map<String, Double>) datosBarrasObj;
                            actualizarGraficoBarras(gastosPorCategoria);
                        }

                        // Verificar y actualizar el gráfico de pie
                        Object datosPieObj = datosPie.get("datos");
                        if (datosPieObj instanceof Map) {
                            @SuppressWarnings("unchecked")
                            Map<String, Double> gastosPorCategoria = (Map<String, Double>) datosPieObj;
                            actualizarGraficoPie(gastosPorCategoria);
                        }

                        // Verificar y actualizar el gráfico de línea
                        Object datosLineaObj = datosLinea.get("datos");
                        if (datosLineaObj instanceof Map) {
                            @SuppressWarnings("unchecked")
                            Map<LocalDate, Map<String, Double>> datosPorFecha = (Map<LocalDate, Map<String, Double>>) datosLineaObj;
                            actualizarGraficoLinea(datosPorFecha);
                        }
                    } catch (Exception e) {
                        mostrarError("Error", "Error al actualizar los gráficos: " + e.getMessage());
                        e.printStackTrace();
                    } finally {
                        // Ocultar indicador de progreso
                        progressIndicator.setVisible(false);
                    }
                });

                return null;
            }
        };

        // Manejar errores
        task.setOnFailed(e -> {
            Throwable exception = task.getException();
            mostrarError("Error", "Error al actualizar gráficos: " + exception.getMessage());
            exception.printStackTrace();
            progressIndicator.setVisible(false);
        });

        // Ejecutar la tarea en un hilo separado
        new Thread(task).start();
    }

    /**
     * Actualiza el gráfico de barras con los datos proporcionados
     * @param gastosPorCategoria Mapa de gastos por categoría
     */
    private void actualizarGraficoBarras(Map<String, Double> gastosPorCategoria) {
        // Limpiar datos anteriores
        barChartCategorias.getData().clear();

        // Verificar si hay datos
        if (gastosPorCategoria == null || gastosPorCategoria.isEmpty()) {
            // Mostrar mensaje en el gráfico
            barChartCategorias.setTitle("No hay datos disponibles");
            return;
        } else {
            barChartCategorias.setTitle("Gastos por categoría");
        }

        // Crear serie de datos
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Gastos");

        // Agregar datos a la serie
        gastosPorCategoria.forEach((categoria, monto) -> {
            if (categoria != null && monto != null) {
                series.getData().add(new XYChart.Data<>(categoria, monto));
            }
        });

        // Verificar si la serie tiene datos
        if (!series.getData().isEmpty()) {
            // Agregar serie al gráfico
            barChartCategorias.getData().add(series);
        }
    }

    /**
     * Actualiza el gráfico de pie con los datos proporcionados
     * @param gastosPorCategoria Mapa de gastos por categoría
     */
    private void actualizarGraficoPie(Map<String, Double> gastosPorCategoria) {
        // Limpiar datos anteriores
        pieChartGastos.getData().clear();

        // Verificar si hay datos
        if (gastosPorCategoria == null || gastosPorCategoria.isEmpty()) {
            // Mostrar mensaje en el gráfico
            pieChartGastos.setTitle("No hay datos disponibles");
            return;
        } else {
            pieChartGastos.setTitle("Distribución de gastos");
        }

        // Crear datos para el gráfico de pie
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();

        // Agregar datos al gráfico
        gastosPorCategoria.forEach((categoria, monto) -> {
            if (categoria != null && monto != null && monto > 0) {
                pieChartData.add(new PieChart.Data(categoria + " ($" + String.format("%.2f", monto) + ")", monto));
            }
        });

        // Verificar si hay datos para mostrar
        if (!pieChartData.isEmpty()) {
            // Agregar datos al gráfico
            pieChartGastos.setData(pieChartData);
        } else {
            // Mostrar mensaje en el gráfico
            pieChartGastos.setTitle("No hay gastos para mostrar");
        }
    }

    /**
     * Actualiza el gráfico de línea con los datos proporcionados
     * @param datosPorFecha Mapa de datos por fecha
     */
    private void actualizarGraficoLinea(Map<LocalDate, Map<String, Double>> datosPorFecha) {
        // Limpiar datos anteriores
        lineChartTendencia.getData().clear();

        // Verificar si hay datos
        if (datosPorFecha == null || datosPorFecha.isEmpty()) {
            // Mostrar mensaje en el gráfico
            lineChartTendencia.setTitle("No hay datos disponibles");
            return;
        } else {
            lineChartTendencia.setTitle("Tendencia de ingresos y gastos");
        }

        // Crear series de datos
        XYChart.Series<String, Number> seriesIngresos = new XYChart.Series<>();
        seriesIngresos.setName("Ingresos");

        XYChart.Series<String, Number> seriesGastos = new XYChart.Series<>();
        seriesGastos.setName("Gastos");

        // Formato para las fechas
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM");

        // Ordenar las fechas cronológicamente
        List<LocalDate> fechasOrdenadas = new ArrayList<>(datosPorFecha.keySet());
        Collections.sort(fechasOrdenadas);

        // Agregar datos a las series
        for (LocalDate fecha : fechasOrdenadas) {
            if (fecha != null) {
                String fechaStr = fecha.format(formatter);
                Map<String, Double> valores = datosPorFecha.get(fecha);

                if (valores != null) {
                    // Agregar ingresos
                    double ingresos = valores.getOrDefault("ingresos", 0.0);
                    if (ingresos > 0) {
                        seriesIngresos.getData().add(new XYChart.Data<>(fechaStr, ingresos));
                    }

                    // Agregar gastos
                    double gastos = valores.getOrDefault("gastos", 0.0);
                    if (gastos > 0) {
                        seriesGastos.getData().add(new XYChart.Data<>(fechaStr, gastos));
                    }
                }
            }
        }

        // Verificar si hay datos para mostrar
        boolean hayDatos = false;

        if (!seriesIngresos.getData().isEmpty()) {
            lineChartTendencia.getData().add(seriesIngresos);
            hayDatos = true;
        }

        if (!seriesGastos.getData().isEmpty()) {
            lineChartTendencia.getData().add(seriesGastos);
            hayDatos = true;
        }

        if (!hayDatos) {
            // Mostrar mensaje en el gráfico
            lineChartTendencia.setTitle("No hay transacciones para mostrar");
        }
    }

    /**
     * Obtiene las transacciones filtradas por fecha de manera optimizada
     * @return Lista de transacciones filtradas
     */
    private List<TransaccionFactory> obtenerTransaccionesFiltradas() {
        try {
            // Obtener las fechas de los controles
            final LocalDate fechaInicioOriginal = dpFechaInicio.getValue();
            final LocalDate fechaFinOriginal = dpFechaFin.getValue();

            // Determinar las fechas finales a utilizar
            final LocalDate fechaInicioFinal;
            final LocalDate fechaFinFinal;

            if (fechaInicioOriginal == null || fechaFinOriginal == null) {
                // Si alguna fecha es nula, usar valores por defecto
                fechaInicioFinal = fechaInicioOriginal != null ? fechaInicioOriginal : LocalDate.now().minusMonths(1);
                fechaFinFinal = fechaFinOriginal != null ? fechaFinOriginal : LocalDate.now();

                // Actualizar los controles de fecha en el hilo de JavaFX
                final LocalDate fechaInicioUI = fechaInicioFinal;
                final LocalDate fechaFinUI = fechaFinFinal;
                Platform.runLater(() -> {
                    dpFechaInicio.setValue(fechaInicioUI);
                    dpFechaFin.setValue(fechaFinUI);
                });
            } else if (fechaInicioOriginal.isAfter(fechaFinOriginal)) {
                // Si la fecha de inicio es posterior a la fecha de fin, intercambiarlas
                fechaInicioFinal = fechaFinOriginal;
                fechaFinFinal = fechaInicioOriginal;

                // Actualizar los controles de fecha en el hilo de JavaFX
                Platform.runLater(() -> {
                    dpFechaInicio.setValue(fechaInicioFinal);
                    dpFechaFin.setValue(fechaFinFinal);
                });
            } else {
                // Usar las fechas originales
                fechaInicioFinal = fechaInicioOriginal;
                fechaFinFinal = fechaFinOriginal;
            }

            // Clave para la caché
            String cacheKey = "transacciones_" + fechaInicioFinal + "_" + fechaFinFinal;

            // Verificar si el resultado está en caché
            if (cacheResultados.containsKey(cacheKey)) {
                return (List<TransaccionFactory>) cacheResultados.get(cacheKey);
            }

            // Obtener todas las transacciones
            List<TransaccionFactory> todasLasTransacciones = billeteraService.obtenerTransaccionesUsuario();

            // Filtrar por fecha de manera optimizada
            List<TransaccionFactory> resultado = PerformanceOptimizer.filtrarTransaccionesPorFecha(
                    todasLasTransacciones, fechaInicioFinal, fechaFinFinal);

            // Limitar el tamaño del caché (máximo 10 entradas)
            if (cacheResultados.size() >= 10) {
                // Eliminar la entrada más antigua
                String claveAntigua = cacheResultados.keySet().iterator().next();
                cacheResultados.remove(claveAntigua);
            }

            // Guardar en caché
            cacheResultados.put(cacheKey, resultado);

            return resultado;
        } catch (Exception e) {
            System.err.println("Error al obtener transacciones filtradas: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>(); // Devolver lista vacía en caso de error
        }
    }

    /**
     * Muestra un diálogo de error
     * @param titulo Título del diálogo
     * @param mensaje Mensaje de error
     */
    private void mostrarError(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    /**
     * Navega al dashboard
     */
    @FXML
    private void irADashboard() {
        try {
            sceneController.cambiarEscena(SceneController.VISTA_DASHBOARD);
        } catch (IOException e) {
            mostrarError("Error", "No se pudo cargar el dashboard: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Cierra la sesión actual y navega a la vista de inicio de sesión
     */
    @FXML
    private void cerrarSesion() {
        try {
            // Limpiar caché antes de cerrar sesión
            limpiarCache();

            // Cerrar sesión
            billeteraService.cerrarSesion();

            // Navegar a la vista de inicio de sesión
            sceneController.cambiarEscena(SceneController.VISTA_SESION);
        } catch (IOException e) {
            mostrarError("Error", "No se pudo cerrar sesión: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Limpia la caché al cerrar la vista
     */
    public void limpiarCache() {
        cacheResultados.clear();
        PerformanceOptimizer.limpiarCache();
    }

    /**
     * Establece el servicio de billetera (para pruebas)
     * @param billeteraService Servicio de billetera
     */
    public void setBilleteraService(BilleteraService billeteraService) {
        this.billeteraService = billeteraService;
    }

    /**
     * Establece el controlador de escenas (para pruebas)
     * @param sceneController Controlador de escenas
     */
    public void setSceneController(SceneController sceneController) {
        this.sceneController = sceneController;
    }
}
