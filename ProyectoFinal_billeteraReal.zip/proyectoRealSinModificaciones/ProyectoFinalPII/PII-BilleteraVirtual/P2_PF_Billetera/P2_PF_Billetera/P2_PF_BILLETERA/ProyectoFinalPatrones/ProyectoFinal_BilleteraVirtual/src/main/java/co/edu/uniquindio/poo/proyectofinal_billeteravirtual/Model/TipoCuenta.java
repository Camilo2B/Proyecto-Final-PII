package co.edu.uniquindio.poo.proyectofinal_billeteravirtual.Model;

public enum TipoCuenta {
    AHORRO,
    CORRIENTE,
    CREDITO,
    EFECTIVO,
    OTRO
}
