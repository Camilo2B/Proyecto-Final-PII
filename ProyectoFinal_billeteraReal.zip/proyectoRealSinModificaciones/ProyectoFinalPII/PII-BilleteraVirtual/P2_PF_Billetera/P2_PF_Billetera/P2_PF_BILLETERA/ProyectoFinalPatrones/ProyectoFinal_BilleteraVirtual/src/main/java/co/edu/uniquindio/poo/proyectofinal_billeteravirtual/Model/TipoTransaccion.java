package co.edu.uniquindio.poo.proyectofinal_billeteravirtual.Model;

public enum TipoTransaccion {
    DEPOSITO,
    RETIRO,
    TRANSFERENCIA
}
